---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME原料缓存器
    icon: extendedae:ingredient_buffer
categories:
- extended devices
item_ids:
- extendedae:ingredient_buffer
---

# ME原料缓存器

<BlockImage id="extendedae:ingredient_buffer" scale="8"></BlockImage>

一个容器，最多可以存储36种任何类型的东西，包括但不限于物品和流体。