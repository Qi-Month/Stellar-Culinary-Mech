---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Crystal Assembler
    icon: extendedae:crystal_assembler
categories:
- extended foundation
item_ids:
- extendedae:crystal_assembler
---

# Crystal Assembler

<Row>
<BlockImage id="extendedae:crystal_assembler" scale="8"></BlockImage>
</Row>

Those extended devices are too complex for crafting table to craft, and you will need Crystal Assembler to craft most of them.

**Notice: The screen face can't connect to network.**

It also can perform certain in-world transformation recipes, like fluix transformation.
