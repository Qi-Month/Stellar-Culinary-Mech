---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Ingot
    icon: extendedae:entro_ingot
categories:
- entro system
item_ids:
- extendedae:entro_ingot
---

# Entro Ingot

<Row>
<ItemImage id="extendedae:entro_ingot" scale="4"></ItemImage>
</Row>

*"Entro Crystal is too friable to use in machine frame, but we can fuse it with gold ingot to improve its ductility."*

It is used to craft <ItemLink id="extendedae:machine_frame" /> and other a few ExtendedAE stuffs.
